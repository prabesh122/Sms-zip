package com.prrabesh.smsvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 0) }

        val enabled = Switch(this).apply {
            text = "Read payment SMS aloud"
            isChecked = p.getBoolean("enabled", true)
        }
        val sender = EditText(this).apply { setText(p.getString("sender", "RBBALERT")); setSingleLine() }
        val keyword = EditText(this).apply { setText(p.getString("keyword", "Transaction success")); setSingleLine() }

        val save = Button(this).apply { text = "Save" }
        val test = Button(this).apply { text = "Test voice" }
        val perm = Button(this).apply { text = "1. Grant permissions" }
        val battery = Button(this).apply { text = "2. Allow background running" }
        val keep = Switch(this).apply {
            text = "Keep-alive notification (more reliable)"
            isChecked = p.getBoolean("keep", false)
        }

        perm.setOnClickListener {
            val perms = mutableListOf(Manifest.permission.RECEIVE_SMS)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
        battery.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
        save.setOnClickListener {
            p.edit()
                .putBoolean("enabled", enabled.isChecked)
                .putString("sender", sender.text.toString().trim())
                .putString("keyword", keyword.text.toString().trim())
                .putBoolean("keep", keep.isChecked)
                .apply()
            val svc = Intent(this, KeepAliveService::class.java)
            if (keep.isChecked && enabled.isChecked) {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
            } else stopService(svc)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        test.setOnClickListener { Speaker.speak(this, "Payment received, 20 rupees") }

        root.addView(perm)
        root.addView(battery)
        root.addView(label("Sender name (leave empty for any)"))
        root.addView(sender)
        root.addView(label("Message must contain (leave empty for any)"))
        root.addView(keyword)
        root.addView(label(""))
        root.addView(enabled)
        root.addView(keep)
        root.addView(save)
        root.addView(test)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
