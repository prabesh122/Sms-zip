package com.prrabesh.smsvoice

import android.content.BroadcastReceiver
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener

object Speaker {
    private val amountRegex = Regex("""Rs\.?\s*([\d,]+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)

    fun parseAmount(body: String): String? {
        val m = amountRegex.find(body) ?: return null
        var s = m.groupValues[1].replace(",", "")
        if (s.contains('.')) s = s.trimEnd('0').trimEnd('.')
        return s
    }

    fun speak(ctx: Context, text: String, pending: BroadcastReceiver.PendingResult? = null) {
        var tts: TextToSpeech? = null
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                pending?.finish(); return@TextToSpeech
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { tts?.shutdown(); pending?.finish() }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { tts?.shutdown(); pending?.finish() }
            })
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sms")
        }
    }
}
