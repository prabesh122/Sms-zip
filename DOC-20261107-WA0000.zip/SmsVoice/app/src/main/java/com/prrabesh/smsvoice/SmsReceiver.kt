package com.prrabesh.smsvoice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!p.getBoolean("enabled", true)) return

        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val sender = msgs[0].originatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val wantSender = p.getString("sender", "RBBALERT") ?: ""
        val wantKeyword = p.getString("keyword", "Transaction success") ?: ""
        if (wantSender.isNotBlank() && !sender.contains(wantSender, ignoreCase = true)) return
        if (wantKeyword.isNotBlank() && !body.contains(wantKeyword, ignoreCase = true)) return

        val amount = Speaker.parseAmount(body)
        val text = if (amount != null) "Payment received, $amount rupees" else body
        Speaker.speak(ctx, text, goAsync())
    }
}
