# SMS Voice

Reads payment SMS aloud (default: sender RBBALERT, text "Transaction success").

## Get the APK (no PC tools needed)
1. Create a free GitHub repo and upload everything in this folder (including the hidden .github folder).
2. Open the repo > Actions tab > "Build APK" > wait ~3-5 min.
3. Open the finished run > Artifacts > download SmsVoice-apk, unzip, install app-debug.apk.

## Or with Android Studio
Open this folder, then Build > Build APK(s).

## First run
Tap "1. Grant permissions", then "2. Allow background running", set sender/keyword, Save.
